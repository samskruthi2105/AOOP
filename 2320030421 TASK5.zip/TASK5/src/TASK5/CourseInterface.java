package TASK5;

public interface CourseInterface {
    void enrollStudent(Student student);
    void displayCourseDetails();
}
