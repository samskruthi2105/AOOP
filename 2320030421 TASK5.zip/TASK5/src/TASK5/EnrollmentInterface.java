package TASK5;

public interface EnrollmentInterface {
    void enrollStudentInCourse();
}
