package TASK5;

public interface StudentInterface {
    void enrollInCourse(Course course);
    void displayStudentDetails();
}
