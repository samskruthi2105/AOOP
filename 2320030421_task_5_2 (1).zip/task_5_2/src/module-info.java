/**
 * 
 */
/**
 * 
 */
module task_5_2 {
	requires org.junit.jupiter.api;
    requires org.junit.jupiter.engine;
    requires org.junit.platform.commons;
	requires java.desktop;
}