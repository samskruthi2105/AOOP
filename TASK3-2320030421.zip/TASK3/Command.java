// Command interface with execute method
public interface Command {
    void execute(String message);
}