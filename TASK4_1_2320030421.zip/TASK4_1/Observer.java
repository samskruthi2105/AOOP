// Interface for observers (bidders)
public interface Observer {
    void update(String event);
}