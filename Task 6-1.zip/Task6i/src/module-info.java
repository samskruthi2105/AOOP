/**
 * 
 */
/**
 * 
 */
module Task6i {
}