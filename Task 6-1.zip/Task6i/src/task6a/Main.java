package task6a;

public class Main {

}
