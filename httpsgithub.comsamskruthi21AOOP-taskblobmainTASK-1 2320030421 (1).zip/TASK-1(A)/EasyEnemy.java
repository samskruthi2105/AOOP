public class EasyEnemy extends Enemy {
    @Override
    public void attack() {
        System.out.println("Easy Enemy attacks with weak force!");
    }
}
