public class EasyPowerUp extends PowerUp {
    @Override
    public void activate() {
        System.out.println("Activating an easy power-up!");
    }
}
