public class EasyWeapon extends Weapon {
    @Override
    public void use() {
        System.out.println("Using an easy weapon!");
    }
}
