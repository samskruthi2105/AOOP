public class HardPowerUp extends PowerUp {
    @Override
    public void activate() {
        System.out.println("Activating a hard power-up!");
    }
}
