public class HardWeapon extends Weapon {
    @Override
    public void use() {
        System.out.println("Using a hard weapon!");
    }
}
