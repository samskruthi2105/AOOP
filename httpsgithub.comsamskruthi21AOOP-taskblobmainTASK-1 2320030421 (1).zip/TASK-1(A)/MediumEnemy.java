public class MediumEnemy extends Enemy {
    @Override
    public void attack() {
        System.out.println("Medium Enemy attacks with moderate force!");
    }
}
