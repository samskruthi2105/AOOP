public class MediumPowerUp extends PowerUp {
    @Override
    public void activate() {
        System.out.println("Activating a medium power-up!");
    }
}
