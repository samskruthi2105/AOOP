public class MediumWeapon extends Weapon {
    @Override
    public void use() {
        System.out.println("Using a medium weapon!");
    }
}
