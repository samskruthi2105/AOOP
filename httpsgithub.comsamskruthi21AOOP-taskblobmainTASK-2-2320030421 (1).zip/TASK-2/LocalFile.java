public class LocalFile {
    public void playLocalFile() {
        System.out.println("Playing music from local file...");
    }
}
