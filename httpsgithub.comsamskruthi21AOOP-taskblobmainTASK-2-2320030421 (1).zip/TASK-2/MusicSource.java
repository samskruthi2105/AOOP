public interface MusicSource {
    void play();
}
