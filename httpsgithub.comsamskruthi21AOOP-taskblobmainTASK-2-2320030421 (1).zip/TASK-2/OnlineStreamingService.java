public class OnlineStreamingService {
    public void playStreamingService() {
        System.out.println("Streaming music from online service...");
    }
}