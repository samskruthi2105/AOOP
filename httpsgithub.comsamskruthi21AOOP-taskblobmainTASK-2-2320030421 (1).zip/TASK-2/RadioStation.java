public class RadioStation {
    public void playRadioStation() {
        System.out.println("Playing music from radio station...");
    }
}
